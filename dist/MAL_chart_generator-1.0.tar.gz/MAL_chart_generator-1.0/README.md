# MAL-chart-generator
# Project for Extended Python course
# README will be filled later
