"""
Module to generate infographic based on myanimelis.net lists
"""
